import { Component, OnInit } from '@angular/core';
import { SearchService } from '../search.service';
import { IBook } from './book';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  book:IBook[];
  constructor(private service:SearchService) { }
$filter :SearchComponent;
  ngOnInit() {
    this.service.getBooks().subscribe(data=>this.book=data);
  }

}
