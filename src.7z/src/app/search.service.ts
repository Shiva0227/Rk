import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IBook } from './search/book';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SearchService {
  url:string="assets/books.json";  
  constructor(private http:HttpClient) { }
  getBooks():Observable<IBook []>
  {
    /* let obj: Observable<IBook []>=this.http.get(this.url);
    return(obj); */
    return this.http.get<IBook []>(this.url);
  }
}
