package com.cg.bank.dao;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;

public interface CustomerDAO {

	public int createAccount(Customer c,Account a);
	public double showBalance(int accountNo);
	public double deposit(double amount,int accountNo);
	public double withdraw(double amount,int accounNo);
	public boolean fundTransfer(double amount,int accountNo1,int accountNo2);
	public Account printTransaction(int accountno);
}
