package com.cg.bank.junit;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.bank.dao.CustomerDAO;
import com.cg.bank.dao.CustomerDAOImpl;
import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;

public class TestCases {

	static CustomerDAO cusdao=null; 
	@BeforeClass
		public static void setUp()
		{
			cusdao=new CustomerDAOImpl();
		} 
	@Test
	public void createAccountTest() {
		Assert.assertEquals(1111, cusdao.createAccount(new Customer(1111, "rkreddy", "2571863258", "ap"), new Account(1111,1,"chennai","MIPL1234",50000)));
	}


}
