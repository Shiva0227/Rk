package com.cg.bank.ui;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.exception.CustomerException;
import com.cg.bank.service.CustomerService;
import com.cg.bank.service.CustomerServiceImpl;

public class RunMain {
	static Scanner sc=null;
	static CustomerService cs=null;
	public static void main(String[] args) throws CustomerException {
		while(true)
		{
		System.out.println("*****Welcome to CG BANK*****");
		System.out.println("Choose your Transaction: \n");
		System.out.println("1.Create a Account\n2.ShowBalance");
		System.out.println("3.Deposit\n4.Withdraw");
		System.out.println("5.FundTransfer");
		sc=new Scanner(System.in);
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			createAccount();
			break;
		case 2:
			showBalance();
			break;
		case 3:
			deposit();
			break;
		case 4:
			withdraw();
			break;
		case 5:
			fundTransfer();
			break;
				
		}
	}
	}
	public static void createAccount() throws CustomerException
	{
		cs=new CustomerServiceImpl();
		String branch="Chennai";
		String IFSCCode="MIPL1234";
		System.out.println("Enter CustomerName: ");
		String name=sc.next();
		try{
		if(cs.validateCustomerName(name))
		{
		System.out.println("Enter Customer MobileNo: ");
		String mobileno=sc.next();
		try{
		if(cs.validateCustomerNo(mobileno))
		{
		System.out.println("Enter Customer address: ");
		String address=sc.next();
		System.out.println("Enter Account type current/savings:");
		String accountType=sc.next();
		System.out.println("Enter the Intial amount to open the account: ");
		double amount=sc.nextDouble();
		 int accountno = (int) (Math.random()*10000);
		 Customer c=new Customer(accountno, name, mobileno, address);
		 Account a=new Account(accountno, accountType, branch, IFSCCode,amount);
		int acc= cs.createAccount(c, a);
		System.out.println("*****Your Account Successfully Created********");
		System.out.println("Your account no. is: "+acc);
		}	
		}
		catch(Exception e)
		{
			throw new CustomerException("Enter valid mobile no");
		}
		}
		}
		catch(Exception e)
		{

			throw new CustomerException("Enter valid name");
		}
	}
	public static void showBalance()
	{
		cs=new CustomerServiceImpl();
		sc=new Scanner(System.in);
		while(true)
		{
		System.out.println("Enter your accountno. ");
		int accountno=sc.nextInt();
		double ac=cs.showBalance(accountno);
		if(ac==0)
		{
			System.out.println("Entered account no. is not Existed..Enter valid Account no.");
			
		}
		else
		{
			System.out.println("Entered Account no: "+accountno+" Current Balance is $"+ac);
			break;
		}
		}
	}
	public static void deposit()
	{
		cs=new CustomerServiceImpl();
		sc=new Scanner(System.in);
		while(true)
		{
		System.out.println("Enter your accountno. ");
		int accountno=sc.nextInt();
		if(cs.showBalance(accountno)!=0)
		{
		System.out.println("Enter Money to Deposit");
		double amount=sc.nextDouble();
		cs.deposit(amount, accountno);
		System.out.println("Successfully Deposited....");
		}
		else
		{
			System.out.println("Entered account no. is not Existed..Enter valid Account no.");
		}
	break;
		}
	}
	public static void withdraw()
	{
		cs=new CustomerServiceImpl();
		sc=new Scanner(System.in);
		while(true)
		{
		System.out.println("Enter your accountno. ");
		int accountno=sc.nextInt();
		if(cs.showBalance(accountno)!=0)
		{
		System.out.println("Enter Money to Withdraw");
		double amount=sc.nextDouble();
		double d=cs.withdraw(amount, accountno);
		if(d==0)
		{
			System.out.println("Insufficient funds need to Deposit: ");
			
		}
		else
		{
			System.out.println("Successfully Withdraw....");

		}
	}
		else
		{
			System.out.println("Entered account no. is not Existed..Enter valid Account no.");
		}break;
	}
		
	}
	public static void fundTransfer()
	{
		cs=new CustomerServiceImpl();
		sc=new Scanner(System.in);
		while(true)
		{
		System.out.println("Enter your accountno. ");
		int accountno=sc.nextInt();
		if(cs.showBalance(accountno)!=0)
		{
			System.out.println("Enter accountno. to transfer the money ");
			int accountno2=sc.nextInt();
			while(true)
			{
			if(cs.showBalance(accountno2)!=0)
			{
				System.out.println("Enter Money to Transfer");
				double amount=sc.nextDouble();
				if(cs.fundTransfer(amount, accountno, accountno2))
				{
					System.out.println("Enter amount successfully Transferred.....");
				}
				else{
					System.out.println("Insufficient funds need to deposit");
					break;
				}
				
			}
			else
			{
				System.out.println("Entered account no. is not Existed..Enter valid Account no.");
			}
			}
			break;
		}
		else
		{
			System.out.println("Entered account no. is not Existed..Enter valid Account no.");
		}break;
		}
	}
	public static void printTransaction(int accountno)
	{
		cs=new CustomerServiceImpl();
		
		System.out.println(cs.printTransaction(accountno));
	}

}
