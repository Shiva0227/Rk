import { Mobile } from "./Mobile";
export class SmartPhone extends Mobile{
    mobileType:string="Smart";
    printMobileDetails()
    {
        console.log(this.mobileID,this.mobileName,this.mobileCost,this.mobileType);
    }
}
