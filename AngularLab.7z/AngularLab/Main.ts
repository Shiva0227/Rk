import { Mobile } from "./Mobile";
import { BasicPhone } from "./BasicPhone";
import { SmartPhone } from "./SmartPhone";
let bm= new BasicPhone();
let sm= new SmartPhone();
sm.printMobileDetails();
bm.printMobileDetails();