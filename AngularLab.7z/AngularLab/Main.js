"use strict";
exports.__esModule = true;
var BasicPhone_1 = require("./BasicPhone");
var SmartPhone_1 = require("./SmartPhone");
var bm = new BasicPhone_1.BasicPhone();
var sm = new SmartPhone_1.SmartPhone();
sm.printMobileDetails();
bm.printMobileDetails();
