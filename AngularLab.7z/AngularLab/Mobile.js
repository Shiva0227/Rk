"use strict";
exports.__esModule = true;
var Mobile = /** @class */ (function () {
    function Mobile() {
        this.mobileID = 1001;
        this.mobileName = 'Sony';
        this.mobileCost = 15000;
    }
    Mobile.prototype.printMobileDetails = function () {
        console.log(this.mobileID, this.mobileName, this.mobileCost);
    };
    return Mobile;
}());
exports.Mobile = Mobile;
