export class Mobile{
    mobileID:number=1001;
    mobileName:String='Sony';
    mobileCost:number=15000;
    printMobileDetails()
    {
        console.log(this.mobileID,this.mobileName,this.mobileCost);
    }
    
}
