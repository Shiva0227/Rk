import { Mobile } from "./Mobile";
export class BasicPhone extends Mobile{
    mobileType:string="Basic";
    printMobileDetails()
    {
        console.log(this.mobileID,this.mobileName,this.mobileCost,this.mobileType);
    }
}