import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class Jdbc {
public static void main(String[] args) throws ClassNotFoundException{
	try {
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","India123");
	con.setAutoCommit(false);
	Statement stmt=con.createStatement();
	//int updatedRow=stmt.executeUpdate("insert into emp1 values(4,6,'rkredddyyy','andhraprad')");
	PreparedStatement pst=con.prepareStatement("insert into emp1 values(?,?,?,?)");
	pst.setInt(1, 105);
	pst.setString(3, "srr");
	pst.setInt(2, 6);
	pst.setString(4, "apradesh");
	pst.execute();
    ResultSet rs= stmt.executeQuery("Select * from emp1");
	while(rs.next())
	{
		int empid=rs.getInt(1);
		int deptid=rs.getInt(2);
		String empname=rs.getString(3);
		String city=rs.getString(4);
		
		System.out.println(empid+"\t"+empname);
		
	}
	con.commit();
} 
	catch (SQLException e) 
	{
	e.printStackTrace();
	System.out.println(e);
	}
}
}
