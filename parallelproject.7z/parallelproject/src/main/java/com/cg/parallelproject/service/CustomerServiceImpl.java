package com.cg.parallelproject.service;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.parallelproject.dao.CustomerDao;
import com.cg.parallelproject.entity.Account;


@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerDao customerDao;
	
	@Override
	public Account createAccount( Account a) {
		Random rand = new Random();
		int acNo = rand.nextInt(900000000) + 1000000000;
		a.setAccountNo(acNo);
		return customerDao.save(a);
	}

	@Override
	public Double showBalance(int accountNo) {
		// TODO Auto-generated method stub
		return customerDao.findById(accountNo).get().getBalance();
	}

	@Override
	public Double deposit(double amount, int accountNo) {
		Account account=customerDao.findById(accountNo).get();
		double bal=account.getBalance()+amount;
		account.setBalance(bal);
		customerDao.save(account);
		return bal;
	}

	@Override
	public Double withdraw(double amount, int accounNo) {
		Account account=customerDao.findById(accounNo).get();
		double bal=account.getBalance()-amount;
		account.setBalance(bal);
		customerDao.save(account);
		return bal;
	}

	@Override
	public Double fundTransfer(double amount, int accountNo1, int accountNo2) {
		Account account=customerDao.findById(accountNo1).get();
		double bal=account.getBalance()-amount;
		account.setBalance(bal);
		customerDao.save(account);
		Account account1=customerDao.findById(accountNo2).get();
		double bal2=account1.getBalance()+amount;
		account1.setBalance(bal2);
		customerDao.save(account1);
		return account.getBalance();
	}

}
