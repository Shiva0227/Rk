package com.cg.parallelproject.service;

import com.cg.parallelproject.entity.Account;


public interface CustomerService {

	public Account createAccount(Account a);
	public Double showBalance(int accountNo);
	public Double deposit(double amount,int accountNo);
	public Double withdraw(double amount,int accounNo);
	public Double fundTransfer(double amount, int accountNo1,int accountNo2);
}
