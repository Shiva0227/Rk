package com.cg.parallelproject.controller;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.cg.parallelproject.entity.Account;
import com.cg.parallelproject.service.CustomerService;


@RestController
public class CustomerController {
	
	@Autowired
	CustomerService customerService;

	
	@RequestMapping(value="/createAccount/{accounttype}/{customerName}/{customeraddress}/{balance}", method=RequestMethod.POST,headers="Accept=application/json")
	public String addTrainee(@PathVariable String accounttype,@PathVariable String customerName,@PathVariable String customeraddress,@PathVariable double balance) {
		Account account=new Account();
		account.setAccountType(accounttype);
		account.setBalance(balance);
		account.setCustomerAddress(customeraddress);
		account.setCustomerName(customerName);
		
		return "Successfully account created: "+customerService.createAccount(account);
	}

	  

/*	@PostMapping(value="/createaccount/{accounttype}/{customerName}/{customeraddress}/{balance}",produces="application/json",consumes= {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<Account> createAccount(@RequestBody Account account) {
		Account e = customerService.createAccount(account);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{accounttype}/{customerName}/{customeraddress}/{balance}").
				build(e.getAccountType(),e.getBalance(),e.getCustomerAddress(),e.getCustomerName());

		return ResponseEntity.created(location).build();	
	}
    */
    
    
	@RequestMapping(value="/showbal/{accountno}", method=RequestMethod.GET,headers="Accept=application/json")
	public String findTrainee(@PathVariable int accountno) {
		return "your current bal is: "+customerService.showBalance(accountno);
	}
	
	
	@RequestMapping(value="/deposit/{accountno}/{balance}", method=RequestMethod.GET,headers="Accept=application/json")
	public String deposited(@PathVariable int accountno,@PathVariable double balance) {
		return "Successfully deposited Your current balance is: "+customerService.deposit(balance,accountno);
	}
	
	
	@RequestMapping(value="/withdraw/{accountno}/{balance}", method=RequestMethod.GET,headers="Accept=application/json")
	public String withdrawn(@PathVariable int accountno,@PathVariable double balance) {
		return "Successfully withdraw your current balance is: "+customerService.withdraw(balance,accountno);
	}
	
	@RequestMapping(value="/fundtransfer/{accountNo1}/{accountNo2}/{amount}", method=RequestMethod.GET,headers="Accept=application/json")
	public String fundtransfer(@PathVariable int accountNo1,@PathVariable int accountNo2,@PathVariable double amount) {
		return "Successfully Transferred.........."+" your current balance is: "+customerService.fundTransfer(amount, accountNo1,accountNo2);
	}
	
}
