package com.cg.parallelproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParallelprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParallelprojectApplication.class, args);
	}

}
