package com.cg.parallelproject.dao;



import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.parallelproject.entity.Account;



public interface CustomerDao extends JpaRepository<Account,Integer>{

	
}
