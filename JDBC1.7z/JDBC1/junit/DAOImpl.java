package com.cg.bank.junit;


import java.sql.SQLException;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.bank.dao.CustomerDAO;
import com.cg.bank.dao.CustomerDAOImpl;
import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;

public class DAOImpl {

	static CustomerDAO cusdao=null; 
	@BeforeClass
		public static void setUp()
		{
			cusdao=new CustomerDAOImpl();
		} 
	@Test
	public void createAccountTest() throws ClassNotFoundException, SQLException {
		Assert.assertEquals("1234", cusdao.createAccount(new Customer("1234", "Harsha", "2571863258", "Mahindracity"), new Account("1234","Current","MahindraCity","HVPL003250",50000)));
	}


}
