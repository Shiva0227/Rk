package com.cg.bank.util;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;



public class Util {
	
    	public static Connection connection() throws SQLException, ClassNotFoundException
    	{
    		Class.forName("oracle.jdbc.driver.OracleDriver");
    		/*Driver d=new oracle.jdbc.driver.OracleDriver();
			DriverManager.registerDriver(d);*/
    		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","India123");
    		return con;
    	}
}
