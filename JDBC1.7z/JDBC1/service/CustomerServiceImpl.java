package com.cg.bank.service;

import java.sql.SQLException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bank.dao.CustomerDAO;
import com.cg.bank.dao.CustomerDAOImpl;
import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;

public class CustomerServiceImpl implements CustomerService{
  static  CustomerDAO cd=new CustomerDAOImpl();
	@Override
	public String createAccount(Customer c, Account a) throws ClassNotFoundException, SQLException {
		
		return cd.createAccount(c, a);
	}

	@Override
	public double showBalance(String accountNo) throws ClassNotFoundException, SQLException {
		
		return cd.showBalance(accountNo);
	}

	@Override
	public double deposit(double amount, String accountNo) throws ClassNotFoundException, SQLException {
		
		return cd.deposit(amount, accountNo);
	}

	@Override
	public double withdraw(double amount, String accounNo) throws ClassNotFoundException, SQLException {
		
		return cd.withdraw(amount, accounNo);
	}

	@Override
	public boolean fundTransfer(double amount, String accountNo1,
			String accountNo2) throws ClassNotFoundException, SQLException {
		
		return cd.fundTransfer(amount, accountNo1, accountNo2);
	}

	@Override
	public List<Account> printTransaction(String accountno) throws SQLException, ClassNotFoundException {
		return cd.printTransaction(accountno);
		
	}

	@Override
	public boolean validateCustomerName(String name) {
		Pattern p=Pattern.compile("^[A-Z]{1}[a-z]*");
		Matcher nMatch=p.matcher(name);
		if(nMatch.matches())
		{
			return true;
		}
		else
		{
		return false;
		}
	}

	@Override
	public boolean validateCustomerNo(String mobileNo) {
		Pattern p=Pattern.compile("^[6-9][0-9]{9}");
		Matcher nMatch=p.matcher(mobileNo);
		if(nMatch.matches())
		{
			return true;
		}
		else
		{
		return false;
		}
	}

}
