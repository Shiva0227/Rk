package com.cg.bank.ui;

import java.sql.SQLException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.exception.CustomerException;
import com.cg.bank.service.CustomerService;
import com.cg.bank.service.CustomerServiceImpl;

public class RunMain {
	static Scanner sc=null;
	static CustomerService cs=null;
	public static void main(String[] args) throws CustomerException, ClassNotFoundException, SQLException {
		while(true)
		{
		System.out.println("*****Welcome to VIJAYA BANK*****");
		System.out.println("Choose your Transaction: \n");
		System.out.println("1.Create a Account\t2.ShowBalance");
		System.out.println("3.Deposit\t4.Withdraw");
		System.out.println("5.FundTransfer");
		sc=new Scanner(System.in);
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			createAccount();
			break;
		case 2:
			showBalance();
			break;
		case 3:
			deposit();
			break;
		case 4:
			withdraw();
			break;
		case 5:
			fundTransfer();
			break;
			
		}
	}
		
	}
	public static void createAccount() throws CustomerException, ClassNotFoundException, SQLException
	{
		cs=new CustomerServiceImpl();
		String branch="Mahindracity";
		String IFSCCode="HVPL003250";
		System.out.println("Enter CustonerName: ");
		String name=sc.next();
		
		if(cs.validateCustomerName(name))
		{
		System.out.println("Enter Customer MobileNo: ");
		String mobileno=sc.next();
		
		if(cs.validateCustomerNo(mobileno))
		{
		System.out.println("Enter Customer address: ");
		String address=sc.next();
		System.out.println("Enter Account type current/savings:");
		String accountType=sc.next();
		System.out.println("Enter the Intial amount to open the account: ");
		int amount=sc.nextInt();
		int min=0,max=53641229;
		 int accountno = (int) (Math.random()*( max-min)+1)+min;
		 Customer c=new Customer(String.valueOf(accountno), name, mobileno, address);
		 Account a=new Account(String.valueOf(accountno), accountType, branch, IFSCCode,amount);
		String acc= cs.createAccount(c, a);
		System.out.println("*****Your Account Successfully Created********");
		System.out.println("Your account no. is: "+acc);
		}	
		
		
		}
		
		
	}
	public static void showBalance() throws ClassNotFoundException, SQLException
	{
		cs=new CustomerServiceImpl();
		sc=new Scanner(System.in);
		while(true)
		{
		System.out.println("Enter your accountno. ");
		String accountno=sc.next();
		double ac=cs.showBalance(accountno);
		if(ac==0)
		{
			System.out.println("Entered account no. is not Existed..Enter valid Account no.");
			
		}
		else
		{
			System.out.println("Entered Account no: "+accountno+" Current Balance is $"+ac);
			break;
		}
		}
	}
	public static void deposit() throws ClassNotFoundException, SQLException
	{
		cs=new CustomerServiceImpl();
		sc=new Scanner(System.in);
		while(true)
		{
		System.out.println("Enter your accountno. ");
		String accountno=sc.next();
		if(cs.showBalance(accountno)!=0)
		{
		System.out.println("Enter Money to Deposit");
		double amount=sc.nextDouble();
		
		cs.deposit(amount, accountno);
		System.out.println("Successfully Deposited....");
		//System.out.println(" Current Balance is $"+d);
		System.out.println("Do you want to print transaction press yes/no");
		String choose=sc.next();
		Pattern p=Pattern.compile("[y][e][s]|[Y][E][S]");
		Matcher nMatch=p.matcher(choose);
		if(nMatch.matches())
		{
			printTransaction(accountno);
			break;
		}
		else
		{
			System.out.println("thankyou");
			break;
		}
		}
		else
		{
			System.out.println("Entered account no. is not Existed..Enter valid Account no.");
		}
	}
	}
	public static void withdraw() throws ClassNotFoundException, SQLException
	{
		cs=new CustomerServiceImpl();
		sc=new Scanner(System.in);
		while(true)
		{
		System.out.println("Enter your accountno. ");
		String accountno=sc.next();
		if(cs.showBalance(accountno)!=0)
		{
		System.out.println("Enter Money to Withdraw");
		double amount=sc.nextDouble();
		double d=cs.withdraw(amount, accountno);
		if(d==0)
		{
			System.out.println("Insufficient funds need to Deposit: ");
			
		}
		else
		{
			System.out.println("Successfully Withdraw....");
			//System.out.println(" Current Balance is $"+d);
		System.out.println("Do you want to print transaction press yes/no");
		String choose=sc.next();
		Pattern p=Pattern.compile("[y][e][s]|[Y][E][S]");
		Matcher nMatch=p.matcher(choose);
		if(nMatch.matches())
		{
			printTransaction(accountno);
			break;
		}
		else
		{
			System.out.println("thankyou");
			break;
		}
		}
	}
		else
		{
			System.out.println("Entered account no. is not Existed..Enter valid Account no.");
		}
	}
		
	}
	public static void fundTransfer() throws ClassNotFoundException, SQLException
	{
		cs=new CustomerServiceImpl();
		sc=new Scanner(System.in);
		while(true)
		{
		System.out.println("Enter your accountno. ");
		String accountno=sc.next();
		if(cs.showBalance(accountno)!=0)
		{
			System.out.println("Enter accountno. to transfer the money ");
			String accountno2=sc.next();
			while(true)
			{
			if(cs.showBalance(accountno2)!=0)
			{
				System.out.println("Enter Money to Transfer");
				double amount=sc.nextDouble();
				if(cs.fundTransfer(amount, accountno, accountno2))
				{
					System.out.println("Enter amount successfully Transferred.....");
					System.out.println("Do you want to print transaction press yes/no");
					String choose=sc.next();
					Pattern p=Pattern.compile("[y][e][s]|[Y][E][S]");
					Matcher nMatch=p.matcher(choose);
					if(nMatch.matches())
					{
						printTransaction(accountno);
						break;
					}
					else
					{
						System.out.println("thankyou");
						break;
					}
				}
				else{
					System.out.println("Insufficient funds need to deposit");
					break;
				}
				
			}
			else
			{
				System.out.println("Entered account no. is not Existed..Enter valid Account no.");
				break;
			}
			}
			break;
		}
		else
		{
			System.out.println("Entered account no. is not Existed..Enter valid Account no.");
		}
		}
	}
	public static void printTransaction(String accountno) throws ClassNotFoundException, SQLException
	{
		cs=new CustomerServiceImpl();
		
		System.out.println(cs.printTransaction(accountno));
	}

}
