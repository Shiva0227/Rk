package com.cg.bank.junit;


import java.sql.SQLException;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.bank.dao.CustomerDAO;
import com.cg.bank.dao.CustomerDAOImpl;
import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;

public class TestCases {

	static CustomerDAO cusdao=null; 
	@BeforeClass
		public static void setUp()
		{
			cusdao=new CustomerDAOImpl();
		} 
	@Test
	public void createAccountTest() throws ClassNotFoundException, SQLException {
		Assert.assertEquals("1234", cusdao.createAccount(new Customer("1234", "rkreddy", "5678", "ap"), new Account("1234",1,"chennai","MIPL1234",50000)));
	}


}
