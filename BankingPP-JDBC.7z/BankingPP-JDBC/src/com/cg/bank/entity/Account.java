package com.cg.bank.entity;

public class Account {

	String accountNumber;
	int accountType;
	String branch;
	String IFSC;
	double balance;
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Account(String accountNumber, int accountType, String branch,
			String iFSC, double balance1) {
		super();
		this.accountNumber = accountNumber;
		this.accountType = accountType;
		this.branch = branch;
		IFSC = iFSC;
		this.balance = balance1;
	}

	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public int getAccountType() {
		return accountType;
	}
	public void setAccountType(int accountType) {
		this.accountType = accountType;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getIFSC() {
		return IFSC;
	}
	public void setIFSC(String iFSC) {
		IFSC = iFSC;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "accountNumber=" + accountNumber + "\n accountType="
				+ accountType + "\n branch=" + branch + "\n IFSC=" + IFSC
				+ "\n balance=" + balance ;
	}
	
	
}
