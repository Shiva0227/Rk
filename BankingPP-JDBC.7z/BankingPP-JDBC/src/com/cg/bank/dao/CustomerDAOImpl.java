package com.cg.bank.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.util.Util;

public class CustomerDAOImpl implements CustomerDAO  {
     static double a=0;
     static double a1=0;
     static String accno1;
     static int acctype1;
     static String ifsc;
     static String branch1;
     static double balance1;
	@Override
	public String createAccount(Customer c, Account a) throws ClassNotFoundException, SQLException {
		Connection con=Util.connection();
		con.setAutoCommit(false);
		PreparedStatement ps=con.prepareStatement("insert into customerdetail values(?,?,?,?)");
		ps.setString(1, c.getAccountNo());
		ps.setString(2,c.getCustomerName());
		ps.setString(3,c.getCustomerMobileNo());
		ps.setString(4,c.getCustomerAddress());
		System.out.println("Details added in customer table");
		ps.execute();
		
		PreparedStatement ps1=con.prepareStatement("insert into accountdetails values(?,?,?,?,?)");
		ps1.setString(1,a.getAccountNumber());
		ps1.setLong(2,a.getAccountType());
		ps1.setString(3,a.getIFSC());
		ps1.setString(4,a.getBranch());
		ps1.setDouble(5, a.getBalance());
		ps1.execute();
		System.out.println("Inserted records into the account table...");
		con.commit();
		return c.getAccountNo();
		
	}

	@Override
	public double showBalance(String accountNo) throws ClassNotFoundException, SQLException {
		
		Connection con=Util.connection();
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery("select balance from accountdetails where ACCOUNTNUMBER='"+accountNo+"'");
		while(rs.next())
		{
		double ac=rs.getDouble("balance");
		a=ac;
		}
		con.commit();
		return a;
	}

	@Override
	public double deposit(double amount, String accountNo) throws ClassNotFoundException, SQLException {
		Connection con=Util.connection();
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery("select balance from accountdetails where ACCOUNTNUMBER='"+accountNo+"'");
		while(rs.next())
		{
		double ac=rs.getDouble("balance");
		a=ac+amount;
		}
		int rs1=stmt.executeUpdate("update accountdetails set balance="+a+" where ACCOUNTNUMBER='"+accountNo+"'");
		con.commit();
		return a;
	}

	@Override
	public double withdraw(double amount, String accountNo) throws ClassNotFoundException, SQLException {
		Connection con=Util.connection();
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery("select balance from accountdetails where ACCOUNTNUMBER='"+accountNo+"'");
		while(rs.next())
		{
		double ac=rs.getDouble("balance");
		a=ac;
		}
		if(amount<=a-500)
		{	
		a=a-amount;
		int rs1=stmt.executeUpdate("update accountdetails set balance="+a+" where ACCOUNTNUMBER='"+accountNo+"'");
		System.out.println("Updated row"+rs1);
		con.commit();
		return a;
		}
		else{
			return 0;
		}
	}

	@Override
	public boolean fundTransfer(double amount, String accountNo1,
			String accountNo2) throws ClassNotFoundException, SQLException {
		Connection con=Util.connection();
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery("select balance from accountdetails where ACCOUNTNUMBER='"+accountNo1+"'");
		while(rs.next())
		{
		double ac=rs.getDouble("balance");
		a=ac;
		}
		if(amount<=a-500)
		{
			
		a=a-amount;
		int rs1=stmt.executeUpdate("update accountdetails set balance="+a+" where ACCOUNTNUMBER='"+accountNo1+"'");
		System.out.println("Updated row"+rs1);
		ResultSet rs2=stmt.executeQuery("select balance from accountdetails where ACCOUNTNUMBER='"+accountNo2+"'");
		while(rs2.next())
		{
		double ac1=rs2.getDouble("balance");
		a1=ac1+amount;
		}
		int rs3=stmt.executeUpdate("update accountdetails set balance="+a1+" where ACCOUNTNUMBER='"+accountNo2+"'");
		System.out.println("Updated row"+rs3);
		con.commit();
		return true;
		}
		else{
		return false;
		}
	
	}

	@Override
	public List<Account> printTransaction(String accountno) throws SQLException, ClassNotFoundException {
		Connection con=Util.connection();
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery("select * from accountdetails where ACCOUNTNUMBER='"+accountno+"'");
		while(rs.next())
		{
			String accno=rs.getString(1);
			int acctype=rs.getInt(2);
			String branch=rs.getString(3);
			String iFsc=rs.getString(4);
		double ac=rs.getDouble(5);
		accno1=accno;
		acctype1=acctype;
		ifsc=iFsc;
		branch1=branch;
		balance1=ac;
		}
    List<Account> accountDetails=new ArrayList<Account>();
    accountDetails.add(new Account(accno1,acctype1,branch1,ifsc,balance1));
		return accountDetails;
	}
	
	
}
